from django.apps import AppConfig


class GmapappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gmapapp'
