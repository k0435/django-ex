from django.apps import AppConfig


class PassdataappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'passdataapp'
