from django.contrib import admin
from newsadmapp import models

admin.site.register(models.NewsUnit)
