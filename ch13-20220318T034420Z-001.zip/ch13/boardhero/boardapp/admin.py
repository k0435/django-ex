from django.contrib import admin
from boardapp import models

admin.site.register(models.BoardUnit)
